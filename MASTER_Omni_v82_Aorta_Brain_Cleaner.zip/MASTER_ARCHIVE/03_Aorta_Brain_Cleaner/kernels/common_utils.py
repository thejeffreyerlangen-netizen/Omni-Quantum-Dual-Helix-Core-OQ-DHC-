"""
Common utilities for Aorta & Brain Clean kernels (v2.0)
Shared residual generation, report helpers, validation.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import numpy as np


def generate_residuals(
    n: int,
    base: float,
    scale: float = 0.05,
    rng: Optional[np.random.Generator] = None,
) -> np.ndarray:
    """Vectorized topological residual (Lambda) generation."""
    if rng is None:
        rng = np.random.default_rng()
    return base * rng.uniform(1.0 - scale, 1.0 + scale, size=n)


def build_report(
    system: str,
    session_id: str,
    total: int,
    passed: int,
    extra: Dict[str, Any],
) -> Dict[str, Any]:
    """Standardized JSON report builder."""
    success_rate = (passed / total) * 100.0 if total > 0 else 0.0
    report = {
        "system": system,
        "session_id": session_id,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "total_cases_simulated": total,
        "successful_passed": passed,
        "success_rate_percent": round(success_rate, 4),
        **extra,
    }
    return report


def pretty_print_report(report: Dict[str, Any]) -> None:
    print("-" * 60)
    print(json.dumps(report, indent=4, ensure_ascii=False))
    print("-" * 60)
