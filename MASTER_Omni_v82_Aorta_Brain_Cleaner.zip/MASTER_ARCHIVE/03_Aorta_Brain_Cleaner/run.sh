#!/usr/bin/env bash
# Omni Super Engine Core 8.2 — One-command launcher (zero external deps)
set -euo pipefail
cd "$(dirname "$0")"
echo "Starting Omni Super Engine Core 8.2 …"
exec python3 backend/server.py
