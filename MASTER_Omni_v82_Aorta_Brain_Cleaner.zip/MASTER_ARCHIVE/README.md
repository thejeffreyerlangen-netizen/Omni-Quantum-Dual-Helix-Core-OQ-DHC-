# Master Archive — Omni v8.2 & Aorta/Brain Cleaner

Konsolidiertes Paket aus Lineage, Codes, Dashboards und Testdaten.

## Struktur

```
MASTER_ARCHIVE/
├── 01_Lineage/
│   └── LINEAGE_Master_Architecture.pdf   ← Chronologie, Architektur, Code-Index
├── 02_Omni_v82/
│   ├── backend/     omni_super_engine_v8_2.py + server.py
│   ├── frontend/    index.html (5 Screens)
│   ├── testdata/    MD · TXT · JSON · PY · PDF Problemstellungen
│   ├── run.sh
│   └── README.md
├── 03_Aorta_Brain_Cleaner/
│   ├── kernels/     brain_clean_v2 · aorta_clean_v2 · common_utils
│   ├── backend/     server.py
│   ├── frontend/    index.html
│   ├── run.sh
│   └── README.md
├── 04_Original_PDFs/
│   └── Aorta & Brain Projekt (Quellen)
└── 05_Exports/      (leer — für Session-JSON)
```

## Schnellstart

**Omni Super Engine Dashboard**
```bash
cd 02_Omni_v82 && ./run.sh
# http://127.0.0.1:8080
```

**Aorta & Brain Cleaner**
```bash
cd 03_Aorta_Brain_Cleaner && ./run.sh
# Port laut server.py (typisch 8000)
```

## Lineage lesen

`01_Lineage/LINEAGE_Master_Architecture.pdf` — Timeline, Module, API, Code-Signaturen, Testfluss.

## Testdaten (Omni)

Unter `02_Omni_v82/testdata/` Dateien per Drag&Drop in den Workbench-Tab laden.
