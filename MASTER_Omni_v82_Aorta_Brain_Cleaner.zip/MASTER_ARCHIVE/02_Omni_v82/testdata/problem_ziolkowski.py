# Omni Super Engine v8.2 — Ziolkowski Trajectory Problem
# Upload this file into the dashboard; KI-parser extracts parameters.

"""
physics_mode = ziolkowski
dimension = 20
relativistic = true

m_payload = 5000
isp = 450
delta_v = 4500
structural_ratio = 0.10

# Expected locked status when trajectory is physical:
# status starts with LOCKED_RELATIVISTIC_TRAJECTORY or LOCKED_LOSSLESS_TRAJECTORY
# residual near 1.64e-07 when LOCKED

# Classical rocket equation (reference):
#   mr = exp(delta_v / (isp * g0))
# Relativistic:
#   log_mr = (c/w) * 0.5 * log((1+v_rel)/(1-v_rel))
"""

PROBLEM_NOTE = """
Führe einen Ziolkowski-Zyklus mit relativistischer Korrektur aus.
Prüfe, ob status LOCKED_* ist und det(J) = 1.0 bleibt.
"""

# Optional initial state (engine will pad/truncate to dimension)
initial_state = "1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1"
