# Omni Super Engine v8.2 — Problemstellung

## Szenario: Full-v8 Stresslauf mit symplektischer Kontrolle

**Ziel:** Einen vollständigen `full_v8`-Zyklus fahren und Residual sowie det(J) prüfen.

### Parameter

- physics_mode = full_v8
- dimension = 24
- seed = 1337
- dt = 0.01
- nu = 0.001
- hyper_coeff = 0.0001
- n_steps = 10
- include_omega = true
- apply_mean = true

### Anfangszustand (ψ)

```
0.10, 0.25, 0.40, 0.55, 0.70, 0.85, 1.00, 1.15,
1.20, 1.05, 0.90, 0.75, 0.60, 0.45, 0.30, 0.15,
0.05, 0.12, 0.28, 0.44, 0.61, 0.77, 0.93, 1.10
```

### Gleichungen / Bedingungen

1. Symplektische Invariante: det(J) ≈ +1.000000
2. Target-Residual: current_residual ≤ 1.75e-7 (wenn erreichbar)
3. Base-Frequenz-Anker: 98.112 Hz
4. Path-Integral mit early_warning-Check; bei Warnung State mit weighted_mean mischen (w=0.3)

### Erwartetes Ergebnis

- status beginnt mit `VERIFIED_FULL_V8` oder `V8_WARNING_*`
- symplectic_determinant im Bereich 0.999 … 1.001
- phase_a und phase_b werden aus dem State-Snapshot abgeleitet

### Notiz

Nach dem Upload soll der KI-Parser Mode, Dimension und State extrahieren.
Anschließend **Einzelzyklus** oder **Batch ×5** ausführen und Export speichern.
