# Testdaten für Omni Super Engine v8.2 Dashboard

Lade die Dateien im Tab **01 Workbench** per Drag & Drop hoch.
Danach optional **KI parsen** klicken und **Einzelzyklus** / **Batch ×5** starten.

| Datei | Mode | Zweck |
|-------|------|--------|
| `problem_full_v8.md` | full_v8 | Vollständiger Stresslauf, Dimension 24, State-Vektor |
| `problem_path_integral.txt` | path_integral | PIMC + Early-Warning |
| `config_navier_stokes.json` | navier_stokes | Hyperviskosität, JSON-Config |
| `problem_ziolkowski.py` | ziolkowski | Relativistische Trajektorie |
| `problem_omega_key.pdf` | omega_key | PDF-Problemstellung, Tensor + det(J) |

## Manuelle Checkliste

1. Server starten: `./run.sh` → http://127.0.0.1:8080  
2. Eine Datei hochladen  
3. Prüfen, ob Parameter (Mode/Dimension/State) übernommen wurden  
4. Zyklus starten → Status, Residual, det(J) in der Kopfzeile  
5. Tab **03 Phasenraum** → zwei Trajektorien  
6. Tab **05 Ergebnisse** → Export herunterladen  
