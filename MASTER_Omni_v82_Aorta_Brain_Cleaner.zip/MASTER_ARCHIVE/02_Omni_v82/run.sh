#!/usr/bin/env bash
cd "$(dirname "$0")/backend"
echo "Omni Super Engine v8.2 Dashboard → http://127.0.0.1:8080"
exec python3 server.py
