#!/usr/bin/env python3
"""
Omni Super Engine v8.2 – Monitoring & Workbench Backend
Multi-screen dashboard: Control · Telemetry · Phase Space · Results
"""
from __future__ import annotations

import json
import time
import traceback
import uuid
from datetime import datetime, timezone
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlparse
import threading
import numpy as np

# Engine import
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from omni_super_engine_v8_2 import SuperEngineOmniCore8Master  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
FRONTEND = ROOT / "frontend"
UPLOADS = ROOT / "uploads"
EXPORTS = ROOT / "exports"
UPLOADS.mkdir(exist_ok=True)
EXPORTS.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
engine = SuperEngineOmniCore8Master(dimension=20, n_paths=48, seed=42)
engine.initialize_state(np.linspace(0.5, 1.5, 20))

TELEMETRY: List[Dict[str, Any]] = []
CYCLE_HISTORY: List[Dict[str, Any]] = []
LAST_RESULT: Optional[Dict[str, Any]] = None
UPLOADED_CONTEXT: List[Dict[str, str]] = []
LOCK = threading.Lock()


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def _json(obj: Any) -> bytes:
    def default(o):
        if isinstance(o, (np.floating, np.integer)):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, complex):
            return {"re": o.real, "im": o.imag}
        raise TypeError(type(o))
    return json.dumps(obj, default=default, indent=2).encode("utf-8")


def push_telemetry(msg: str, level: str = "info"):
    with LOCK:
        TELEMETRY.append({"t": _now(), "level": level, "msg": msg})
        if len(TELEMETRY) > 200:
            TELEMETRY.pop(0)


# ---------------------------------------------------------------------------
# Core cycle runner
# ---------------------------------------------------------------------------
def run_cycle(payload: Dict[str, Any]) -> Dict[str, Any]:
    global LAST_RESULT
    mode = payload.get("physics_mode", "standard")
    dim = int(payload.get("dimension", engine.dimension))
    if dim != engine.dimension:
        engine.set_dimension(dim)

    # optional state from user
    state_raw = payload.get("initial_state")
    if state_raw is not None:
        try:
            if isinstance(state_raw, str):
                vec = np.array([float(x.strip()) for x in state_raw.replace(";", ",").split(",") if x.strip()])
            else:
                vec = np.asarray(state_raw, dtype=float).ravel()
            if len(vec) == engine.dimension:
                engine.initialize_state(vec)
            elif len(vec) > 0:
                # pad / truncate
                out = np.zeros(engine.dimension)
                out[: min(len(vec), engine.dimension)] = vec[: engine.dimension]
                engine.initialize_state(out)
        except Exception as e:
            push_telemetry(f"State parse error: {e}", "warn")

    kwargs = {
        "dt": float(payload.get("dt", 0.01)),
        "nu": float(payload.get("nu", 0.001)),
        "hyper_coeff": float(payload.get("hyper_coeff", 1e-4)),
        "n_steps": int(payload.get("n_steps", 8)),
        "noise_scale": float(payload.get("noise_scale", 0.05)),
        "apply_mean": bool(payload.get("apply_mean", True)),
        "include_omega": bool(payload.get("include_omega", False)),
        "relativistic": bool(payload.get("relativistic", True)),
        "m_payload": float(payload.get("m_payload", 5000)),
        "isp": float(payload.get("isp", 450)),
        "delta_v": float(payload.get("delta_v", 4500)),
        "structural_ratio": float(payload.get("structural_ratio", 0.1)),
    }

    t0 = time.perf_counter()
    try:
        result = engine.execute_evolution_cycle(mode, **kwargs)
        wall = time.perf_counter() - t0
        result["wall_time_s"] = wall
        result["physics_mode"] = mode
        result["timestamp"] = _now()
        result["dimension"] = engine.dimension

        # phase-space helpers (two trajectories for dual 4D views)
        psi = np.asarray(result["state_snapshot"], dtype=float)
        n = len(psi)
        t = np.linspace(0, 2 * np.pi, n)
        # trajectory A: (q1, q2, p1) from state + synthetic conjugate
        q1 = psi
        q2 = np.roll(psi, 1)
        p1 = np.gradient(psi)
        result["phase_a"] = {
            "q1": q1.tolist(),
            "q2": q2.tolist(),
            "p1": p1.tolist(),
            "label": "Phasenraum A – State / Gradient",
        }
        # trajectory B: symplectic-like closed orbit scaled by residual
        res = float(result.get("current_residual") or 0)
        amp = 0.4 + min(abs(res) * 1e5, 0.6)
        theta = np.linspace(0, 4 * np.pi, 120)
        result["phase_b"] = {
            "q1": (amp * np.cos(theta)).tolist(),
            "q2": (amp * np.sin(theta)).tolist(),
            "p1": (amp * 0.5 * np.sin(2 * theta)).tolist(),
            "label": "Phasenraum B – Symplektische Orbit",
        }

        with LOCK:
            LAST_RESULT = result
            CYCLE_HISTORY.append({
                "t": result["timestamp"],
                "mode": mode,
                "residual": result.get("current_residual"),
                "det": result.get("symplectic_determinant"),
                "status": result.get("status"),
                "wall": wall,
            })
            if len(CYCLE_HISTORY) > 100:
                CYCLE_HISTORY.pop(0)

        push_telemetry(
            f"CYCLE {mode} · status={result.get('status')} · res={result.get('current_residual'):.3e} · det={result.get('symplectic_determinant'):.6f}",
            "ok",
        )
        return result
    except Exception as e:
        push_telemetry(f"CYCLE ERROR: {e}", "error")
        return {"status": "ERROR", "message": str(e), "trace": traceback.format_exc()}


def parse_uploaded_text(text: str, filename: str) -> Dict[str, Any]:
    """Extract numbers, mode hints, and equations from free text / markdown."""
    import re
    hints: Dict[str, Any] = {"filename": filename, "raw_preview": text[:800]}
    # dimension
    m = re.search(r"dimension\s*[=:]\s*(\d+)", text, re.I)
    if m:
        hints["dimension"] = int(m.group(1))
    # seed
    m = re.search(r"seed\s*[=:]\s*(\d+)", text, re.I)
    if m:
        hints["seed"] = int(m.group(1))
    # mode keywords
    modes = ["full_v8", "path_integral", "navier_stokes", "ziolkowski", "omega_key", "adaptive", "topology", "standard"]
    for mode in modes:
        if mode.replace("_", " ") in text.lower() or mode in text.lower():
            hints["physics_mode"] = mode
            break
    # numbers that look like initial state (long comma list)
    m = re.search(r"(?:state|vector|psi|anfang)[^\d\-]*([\d\.\-\+eE,\s]{20,})", text, re.I)
    if m:
        hints["initial_state"] = m.group(1).strip()
    # equations (lines with = and math-ish)
    eqs = re.findall(r"^.{0,40}[=≈].{0,60}$", text, re.M)
    if eqs:
        hints["equations"] = eqs[:12]
    return hints


# ---------------------------------------------------------------------------
# HTTP Handler
# ---------------------------------------------------------------------------
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(FRONTEND), **kwargs)

    def log_message(self, fmt, *args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _send(self, code: int, body: bytes, ctype: str = "application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/health":
            self._send(200, _json({
                "engine": "Omni Super Engine v8.2",
                "status": "ONLINE",
                "dimension": engine.dimension,
                "base_frequency": engine.env.base_frequency,
                "cycles_run": len(CYCLE_HISTORY),
            }))
            return

        if path == "/api/telemetry":
            with LOCK:
                data = list(TELEMETRY[-80:])
            self._send(200, _json({"stream": data}))
            return

        if path == "/api/history":
            with LOCK:
                data = list(CYCLE_HISTORY)
            self._send(200, _json({"history": data}))
            return

        if path == "/api/last":
            with LOCK:
                data = LAST_RESULT
            self._send(200, _json(data or {"status": "NO_CYCLE_YET"}))
            return

        if path == "/api/context":
            self._send(200, _json({"uploads": UPLOADED_CONTEXT}))
            return

        if path.startswith("/api/export/"):
            name = path.split("/")[-1]
            fp = EXPORTS / name
            if fp.exists():
                data = fp.read_bytes()
                self._send(200, data, "application/octet-stream")
            else:
                self._send(404, _json({"error": "not found"}))
            return

        # static
        if path == "/" or path == "":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"

        # multipart upload
        if path == "/api/upload":
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" not in ctype:
                self._send(400, _json({"error": "multipart required"}))
                return
            # simple boundary parse
            boundary = ctype.split("boundary=")[-1].encode()
            parts = raw.split(b"--" + boundary)
            saved = []
            for part in parts:
                if b"Content-Disposition" not in part:
                    continue
                header, _, body = part.partition(b"\r\n\r\n")
                body = body.rstrip(b"\r\n--")
                fname = b"upload.bin"
                if b'filename="' in header:
                    fname = header.split(b'filename="')[1].split(b'"')[0]
                name = fname.decode("utf-8", errors="ignore") or f"file_{uuid.uuid4().hex[:8]}"
                safe = "".join(c for c in name if c.isalnum() or c in "._-")[:80]
                dest = UPLOADS / safe
                dest.write_bytes(body)
                text = ""
                try:
                    text = body.decode("utf-8", errors="ignore")
                except Exception:
                    pass
                hints = parse_uploaded_text(text, safe) if text else {"filename": safe}
                entry = {"filename": safe, "bytes": len(body), "hints": hints, "preview": text[:500]}
                UPLOADED_CONTEXT.append(entry)
                saved.append(entry)
                push_telemetry(f"UPLOAD {safe} ({len(body)} B)", "info")
            self._send(200, _json({"saved": saved}))
            return

        # JSON body
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            payload = {}

        if path == "/api/cycle":
            result = run_cycle(payload)
            self._send(200, _json(result))
            return

        if path == "/api/batch":
            n = int(payload.get("n_cycles", 5))
            mode = payload.get("physics_mode", "full_v8")
            results = []
            for i in range(n):
                r = run_cycle({**payload, "physics_mode": mode})
                results.append({
                    "i": i,
                    "residual": r.get("current_residual"),
                    "status": r.get("status"),
                    "det": r.get("symplectic_determinant"),
                })
            self._send(200, _json({"batch": results, "n": n}))
            return

        if path == "/api/ai-parse":
            # lightweight "agent": extract structure from free text / speech transcript
            text = payload.get("text", "")
            hints = parse_uploaded_text(text, "ai_input")
            # also try to detect equations as mode triggers
            push_telemetry(f"AI-PARSE: mode={hints.get('physics_mode','?')} dim={hints.get('dimension','?')}", "info")
            self._send(200, _json({"hints": hints, "suggested_payload": {
                "physics_mode": hints.get("physics_mode", "standard"),
                "dimension": hints.get("dimension", engine.dimension),
                "initial_state": hints.get("initial_state"),
            }}))
            return

        if path == "/api/export":
            with LOCK:
                data = {
                    "exported_at": datetime.now(timezone.utc).isoformat(),
                    "engine": "Omni Super Engine v8.2",
                    "last_result": LAST_RESULT,
                    "history": list(CYCLE_HISTORY),
                    "telemetry": list(TELEMETRY[-50:]),
                    "uploads": UPLOADED_CONTEXT,
                }
            name = f"omni_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            (EXPORTS / name).write_bytes(_json(data))
            push_telemetry(f"EXPORT {name}", "ok")
            self._send(200, _json({"filename": name, "url": f"/api/export/{name}"}))
            return

        if path == "/api/reset":
            engine.set_dimension(20)
            engine.initialize_state(np.linspace(0.5, 1.5, 20))
            with LOCK:
                TELEMETRY.clear()
                CYCLE_HISTORY.clear()
                LAST_RESULT = None
            push_telemetry("SESSION RESET", "info")
            self._send(200, _json({"ok": True}))
            return

        self._send(404, _json({"error": "unknown endpoint"}))


def main():
    push_telemetry("Omni Super Engine v8.2 ONLINE · base_freq=98.112 Hz", "ok")
    host, port = "127.0.0.1", 8080
    print(f"Omni v8.2 Dashboard → http://{host}:{port}")
    HTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
