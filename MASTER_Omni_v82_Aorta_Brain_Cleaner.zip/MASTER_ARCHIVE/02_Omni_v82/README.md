# Omni Super Engine v8.2 — Monitoring Dashboard

Multi-Screen Workbench für den Quantum-Topological Core.

## Start

```bash
cd backend
python3 server.py
```

Dann im Browser: **http://127.0.0.1:8080**

Voraussetzung: Python 3.9+, NumPy. Optional: PyTorch, SciPy.

## Screens

1. **Workbench** — Problem/Gleichung, KI-Parse, Upload, Parameter, KPI
2. **Telemetrie** — Live-Stream + Zyklus-Historie
3. **Phasenraum** — zwei 4D-Phasenräume (State/Gradient + Symplektische Orbit)
4. **Diagramme** — Residual, det(J), Wall-Time, Status
5. **Ergebnisse** — JSON + Session-Export

## API (Kurz)

| Endpoint | Methode | Beschreibung |
|----------|---------|--------------|
| `/api/health` | GET | Engine-Status |
| `/api/cycle` | POST | Einzelzyklus |
| `/api/batch` | POST | Mehrere Zyklen |
| `/api/telemetry` | GET | Stream |
| `/api/upload` | POST | Multipart-Dateien |
| `/api/ai-parse` | POST | Text → Parameter |
| `/api/export` | POST | Session als JSON |

## Dateien

- `backend/omni_super_engine_v8_2.py` — Core 8 Engine
- `backend/server.py` — HTTP-Backend (stdlib)
- `frontend/index.html` — Dashboard UI
