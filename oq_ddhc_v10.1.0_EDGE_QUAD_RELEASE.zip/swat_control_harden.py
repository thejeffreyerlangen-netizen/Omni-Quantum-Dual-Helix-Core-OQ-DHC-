class OQHardwareHardenV10:
    def __init__(self):
        self.REG_ADDR_BASE = 0x4000F000
        self.REG_OFFSETS = {
            "GLOBAL_ENABLE": 0x00,
            "ISOLATION_TIME_PS": 0x04,
            "TIMEOUT_LIMIT_NS": 0x08
        }
        
    def generiere_register_konfiguration(self, isolation_ps: int = 12) -> dict:
        if not (0 <= isolation_ps <= 100):
            raise ValueError("Isolations-Zeit außerhalb der Hardware-Toleranz.")
            
        payload = {
            hex(self.REG_ADDR_BASE + self.REG_OFFSETS["GLOBAL_ENABLE"]): 0x00000001,
            hex(self.REG_ADDR_BASE + self.REG_OFFSETS["ISOLATION_TIME_PS"]): int(isolation_ps),
            hex(self.REG_ADDR_BASE + self.REG_OFFSETS["TIMEOUT_LIMIT_NS"]): 0x000249F0
        }
        return payload

if __name__ == "__main__":
    hardener = OQHardwareHardenV10()
    reg_set = hardener.generiere_register_konfiguration(12)
    for reg, val in reg_set.items():
        print(f" -> Register [{reg}]: {hex(val)}")
